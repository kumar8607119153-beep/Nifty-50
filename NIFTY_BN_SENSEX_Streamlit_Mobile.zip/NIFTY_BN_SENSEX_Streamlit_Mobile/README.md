# Mobile Streamlit Dashboard

NIFTY / BANK NIFTY / SENSEX dashboard packaged for Android/mobile Chrome.

Deploy `app.py` with Streamlit Community Cloud.
